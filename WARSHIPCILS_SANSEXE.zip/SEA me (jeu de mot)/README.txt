Projet Bataille Navale du Groupe 6 :

REMARQUE : Dans le projet originale, des images sont présentes pour ambiancer le tout. Normalement il y a un fond pour le menu
et un fond pour le jeu, avec des images en cas de défaites/victoires ou d'un bateau coulé. Cependant, l'executable ne les affiche
pourtant, on peut les voir à partir de l'IDE.

Voici le projet de la bataille navale du groupe 6 en Java Orienté Objet réalisé par Prévot Alexandre, Rosinski Raphaël, Rafanel Alexandre.
Ce logiciel utilise JavaFX.
Afin de lancer le projet, veuillez lancer l'exécutable "WARSHIPEXE.jar"

Ce projet permet :
-Sur la première fenêtre, de sélectionner le mode 1 joueur ou le mode 2 joueurs
-Sur la deuxième fenêtre, de choisir un mode de jeu entre Démo, Bataille Classique, Misson Radar, Alerte Rouge et Opération Artillerie
-Sur la troisième fenêtre, d'augmenter et de diminuer les nombres de bateaux avec lesquels ont souhaite jouer
Lorsque l'on choisit des bateaux, ces derniers dépendent du nombre qu'on a choisit:
(Il faut prendre 5 bateaux pour avoir le sous-marin, 4 pour le zodiac, 2 pour le cuirassé et 1 pour le porte-avion)
Chaques joueurs possèdent les mêmes types de bateaux pour une question d'égalité

Lorsqu'on se trouve sur la fenêtre de jeu (Fenêtre où sont les deux plateaux): 

Si vous voulez poser un bateau il faut cliquer sur le plateau indiqué par la barre rouge en dessous:
- Clique gauche pour un placement verticale (Le nez du bateau se trouve au curseur de la souris, puis le bateau apparait du curseur vers le bas)
- Clique droit pour un placement horizontale (Le nez du bateau se trouve au curseur de la souris, puis le bateau apparait du curseur vers la droite)

Vous pouvez enlever un bateau que vous avez placé en recliquant dessus, il sera alors possible de le replacer.

ATTENTION : Le dernier bateau posé d'un plateau, validera la position de tous les bateaux déjà posés:
- Soit la partie commencera si le mode 1 joueur est sélectionné
- Soit ce sera au tour du joueur 2 de poser ses bateaux

Si le bateau n'apparaît pas c'est que le placement est illégal, c'est à dire qu'il n'y a pas la place de poser le bateau .

Il faut cliquer sur son propre plateau pour pouvoir commencer son tour(pouvoir tirer) dans les modes suivants:

- Mission Radar
- Alerte Rouge 
- Opération Artillerie

Le mode Mission Radar fournit après un tir manqué la zone la plus petite dans laquelle se trouve un morceau du bateau le plus proche autour de la position du tir manqué.

Le mode Opération Artillerie : 
- Vous choisissez la ligne sur lequel vous voulez tirer sur le plateau du joueur dont c'est le tour de façon horizontale, puis il clique afin de valider la ligne sur laquelle on souhaite tirer
- S'en suit un défilement de la ligne précédemment sélectionné (case par case) afin de valider la position du tir

Le mode Alerte Rouge, regroupe tous les modes de jeux existants : Bataille Classique, Mission Radar, Opération Artillerie

Le mode Démo permet de vous entrainer contre une IA avec un bateau seulement, avec tous les bateaux visibles.

DEFAUT :

Si l'on joue trop vite, il est possible que l'IA se bloque.
Parfois l'IA d'AlerteRouge peut se coincer dans une boucle infinie parcequ'elle a choisie de tirer sur la première ligne.
On a pas eu le temps de régler le soucis, mais il est réglable très facilement.
