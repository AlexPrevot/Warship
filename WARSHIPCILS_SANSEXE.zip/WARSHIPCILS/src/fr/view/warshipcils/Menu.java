package fr.view.warshipcils;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import fr.model.warshipcils.Main;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.scene.paint.Color;
import javafx.util.Duration;

public class Menu extends Application implements EventHandler<ActionEvent>{

	int heightScreen =350;
	String modeJoueur;
	String modeDeJeu;
	int nbrBateau = 0;
	Text txtBoat;
	Text txt;
	
	public static void main(String[] args) {
		launch(args);
		}
		
	
	
	@Override
	public void start(Stage stage) throws Exception {
		stage.setTitle("WARSHIPCILS-Menu");
		
		stage.setResizable(false);
		
		Image image = new Image("file:src/image/WarshipBackground.jpg");
		Image image2 = new Image("file:src/image/WarshipBackground.jpg");
		Image image3 = new Image("file:src/image/WarshipBackground.jpg");
		ImageView mv = new ImageView(image);
		ImageView mv2 = new ImageView(image2);
		ImageView mv3 = new ImageView(image3);
		
		StackPane tout = new StackPane();
		StackPane tout2 = new StackPane();
		StackPane tout3 = new StackPane();
		
		Group root = new Group();
		Group choixMode = new Group();
		Group choixBoat = new Group();
		
		Pane nbrBoat = new Pane();
		
		txt = new Text ("Vous avez choisi ce nombre de bateau :" + Integer.toString(nbrBateau));
		
		nbrBoat.getChildren().add(txt);
		
		choixBoat.getChildren().add(nbrBoat);
		
		Button modeDemo = new Button("MODE DEMO");
		
		root.getChildren().add(modeDemo);
		
		nbrBoat.setLayoutX(0);
		nbrBoat.setLayoutY(150);
		
		tout.getChildren().add(mv);
		tout2.getChildren().add(mv2);
		tout3.getChildren().add(mv3);
		
		tout.getChildren().add(root);
		tout2.getChildren().add(choixMode);
		tout3.getChildren().add(choixBoat);
		
		Scene sceneJoueur = new Scene(tout,heightScreen,heightScreen-heightScreen/3);
		Scene sceneModeJeu = new Scene(tout2,heightScreen,heightScreen-heightScreen/3);
		Scene sceneNbrBoat = new Scene(tout3, heightScreen,heightScreen-heightScreen/3);
		
		//bouton pour rajouter ou enlever des bateaux
		Button buttonMoreBoat = new Button("Rajouter un bateau");
		Button buttonLessBoat = new Button("Enlever un bateau");
		Button valider = new Button("VALIDER");
		choixBoat.getChildren().add(buttonMoreBoat);
		choixBoat.getChildren().add(buttonLessBoat);
		choixBoat.getChildren().add(valider);
		
		//Bouton pour choisir l'IA ou le joueur
		Button button1J = new Button("MODE 1 JOUEUR");
		Button button2J = new Button("MODE 2 JOUEUR");
		root.getChildren().add(button1J);
		root.getChildren().add(button2J);
		//Bouton pour choisir le mode de jeu
		Button buttonBatailleClassique = new Button("Bataille Classique");
		Button buttonMissionRadar = new Button("Mission Radar");
		Button buttonOperationArtillerie = new Button("Op�ration Artillerie");
		Button buttonAlerteRouge = new Button("AlerteRouge");
		choixMode.getChildren().add(buttonBatailleClassique);
		choixMode.getChildren().add(buttonMissionRadar);
		choixMode.getChildren().add(buttonOperationArtillerie);
		choixMode.getChildren().add(buttonAlerteRouge);
		
		StackPane retour = new StackPane();
		Button buttonRetour = new Button("Retour");
		
		
		buttonBatailleClassique.setLayoutX(heightScreen/2);
		buttonBatailleClassique.setLayoutY(heightScreen/5);
		buttonMissionRadar.setLayoutX(heightScreen/2);
		buttonMissionRadar.setLayoutY(2*heightScreen/5);
		buttonOperationArtillerie.setLayoutX((heightScreen)/2);
		buttonOperationArtillerie.setLayoutY((3*heightScreen)/5);
		buttonAlerteRouge.setLayoutX(heightScreen/2);
		buttonAlerteRouge.setLayoutY(4*heightScreen/5);
		
		button1J.setLayoutX(heightScreen/2);
		button1J.setLayoutY(heightScreen/3);
		button2J.setLayoutX(heightScreen/2);
		button2J.setLayoutY(heightScreen/2);
		modeDemo.setLayoutX(heightScreen/2);
		modeDemo.setLayoutY(heightScreen*(2/3));
		
		buttonMoreBoat.setLayoutX(heightScreen/2);
		buttonMoreBoat.setLayoutY(heightScreen/4);
		buttonLessBoat.setLayoutX(heightScreen/2);
		buttonLessBoat.setLayoutY((3*heightScreen)/4);
		
		valider.setLayoutX(heightScreen/2);
		valider.setLayoutY(heightScreen/2);
		
		modeDemo.setOnAction(new EventHandler<ActionEvent>(){
			
			@Override
			public void handle(ActionEvent event) {
				modeJoueur = "IA";
				modeDeJeu = "BatailleClassique";
				nbrBateau = 1;
				Main.setDemot();
				setGame();
				stage.close();
			}
		
		
	});
		
		button1J.setOnAction(new EventHandler<ActionEvent>(){
				
				@Override
				public void handle(ActionEvent event) {
					modeJoueur = "IA";
					stage.setScene(sceneModeJeu);
					stage.show();
				}
			
			
		});

		button2J.setOnAction(new EventHandler<ActionEvent>(){
		
			@Override
			public void handle(ActionEvent event) {
				modeJoueur = "joueur";
				stage.setScene(sceneModeJeu);
				stage.show();
			}
		});
		
		buttonBatailleClassique.setOnAction(new EventHandler<ActionEvent>(){
			
			@Override
			public void handle(ActionEvent event) {
				modeDeJeu = "BatailleClassique";
				stage.setScene(sceneNbrBoat);
				stage.show();
			}
		});
		
		buttonMissionRadar.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent event) {
				modeDeJeu = "MissionRadar";
				stage.setScene(sceneNbrBoat);
				stage.show();
			}
		});
		
		buttonOperationArtillerie.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent event) {
				modeDeJeu = "OperationArtillerie";
				stage.setScene(sceneNbrBoat);
				stage.show();
			}
		});
		
		buttonAlerteRouge.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent event) {
				modeDeJeu = "AlerteRouge";
				stage.setScene(sceneNbrBoat);
				stage.show();
			}
		});
		
		buttonMoreBoat.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent event) {
				if (nbrBateau < 5) nbrBateau++;
				nbrBoat.getChildren().remove(txt);
				txt = new Text ("Vous avez choisi ce nombre de bateau :" + Integer.toString(nbrBateau));
				nbrBoat.getChildren().add(txt);
			}
		});
		
		buttonLessBoat.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent event) {
				if (nbrBateau > 1) nbrBateau--;
				nbrBoat.getChildren().remove(txt);
				txt = new Text ("Vous avez choisi ce nombre de bateau :" + Integer.toString(nbrBateau));
				nbrBoat.getChildren().add(txt);
			}
		});
		
		valider.setOnAction(new EventHandler<ActionEvent>(){
			@Override
			public void handle(ActionEvent event) {
				if (nbrBateau > 0) {
					setGame();
					stage.close();
				}
			}
		});
		
		//sceneJoueur.setFill(mv);
		stage.setScene(sceneJoueur);
		stage.show();
	}



	@Override
	public void handle(ActionEvent arg0) {
		
		
	}
	
	
	public void setGame() {
		Main.setMode(modeDeJeu, modeJoueur, nbrBateau);
		
	}

}
