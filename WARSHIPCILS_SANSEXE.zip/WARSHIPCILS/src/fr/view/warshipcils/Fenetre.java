package fr.view.warshipcils;


import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.*;
import javafx.scene.text.Text;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.EventHandler;
import javafx.scene.paint.Color;
import javafx.util.Duration;

import java.util.ArrayList;


import fr.controller.warshipcils.Souris;
import fr.model.warshipcils.AlerteRouge;
import fr.model.warshipcils.Bateau;
import fr.model.warshipcils.IA;
import fr.model.warshipcils.JeuPlat;
import fr.model.warshipcils.Main;
import fr.model.warshipcils.ModeJeu;

public class Fenetre  {
	
	static int tailleCase = 30;
	static int spaceBetweenCase = 0;
	static int spaceBetweenPlat = 1;
	static int platSpace = (tailleCase + spaceBetweenCase) * spaceBetweenPlat;
	static Group plat = new Group();
	StackPane partie = new StackPane();
	static Group rootPlat1 = new Group();
	static Group rootPlat2 = new Group();
	static Rectangle posMouse = new Rectangle();
	static Rectangle artillerieCase = new Rectangle();
	static Timeline animation;
	static boolean animateCurrently = false;
	static short artillerieDir = 1;
	static boolean radarClignote;
	static int alerteRougeY;
	static ArrayList<Rectangle> listeZoneRad = new ArrayList<Rectangle>();
	static ArrayList<Rectangle> opAMouseCase = new ArrayList<Rectangle>();
	static JeuPlat jp1 = Main.getPlat(1);
	static JeuPlat jp2 = Main.getPlat(2);
	static Stage primaryStage;
	static Rectangle cliqueIci = new Rectangle();
	static Text demoTxt;
	
	public static void display(String[] args) {
		
	//launch(args);
	}
	
	public static int getSpaceBetweenPlat() {
		return spaceBetweenPlat;
	}
	
	public static int getSpace() {
		return spaceBetweenCase;
	}
	
	public static int getTailleCase() {
		return tailleCase;
	}
	
	public static Group getPlat(){
		return plat;
	}
	
	public static Timeline getAnim() {
		return animation;
	}
	
	public static boolean getIsAnimating() {
		return animateCurrently;
	}
	
	public static void setIsAnimating() {
		animateCurrently = true;
	}

	public void start() {
	primaryStage = new Stage();
	primaryStage.setTitle("Warship CILS");
	
	primaryStage.setResizable(false);
	
	Image image = new Image("file:src/image/fondJeu.jpg");
	ImageView mv = new ImageView(image);
	
	mv.setFitWidth(800);
	mv.setFitHeight(600);
	
	
	cliqueIci.setX(convertTabNToN(JeuPlat.getPlatTaille() + Fenetre.getSpaceBetweenPlat()) + 85);
	cliqueIci.setY(convertTabNToN(JeuPlat.getPlatTaille()) + 150);
	cliqueIci.setWidth(convertTabNToN(JeuPlat.getPlatTaille()));
	cliqueIci.setHeight(50);
	cliqueIci.setFill(Color.RED);
	
	
	
	//plat.getChildren().add(cliqueIci);
	Pane ici = new Pane();
	/*Pane txtPourDemo = new Pane();
	demoTxt = new Text ("ISSOU LO CHANCLO");
	
	txtPourDemo.setLayoutX(convertTabNToN(JeuPlat.getPlatTaille() + Fenetre.getSpaceBetweenPlat()) + 85);
	txtPourDemo.setLayoutX(convertTabNToN(JeuPlat.getPlatTaille()) + 150);
	txtPourDemo.getChildren().add(demoTxt);
	
	
	
	ici.getChildren().add(txtPourDemo);*/
	ici.getChildren().add(cliqueIci);
	
	
	
	partie.getChildren().add(mv);
	
	partie.getChildren().add(ici);
	
	partie.getChildren().add(plat);
	
	//partie.getChildren().add(ici);
	
	
	
	Scene scene = new Scene(partie,800,600);
	
	Souris.mouseAction(plat);
	
	posMouse.setWidth(tailleCase);
	posMouse.setHeight(tailleCase);
	posMouse.setArcWidth(10);
	posMouse.setArcHeight(10);
	
	artillerieCase.setWidth(tailleCase);
	artillerieCase.setHeight(tailleCase);
	artillerieCase.setArcWidth(10);
	artillerieCase.setArcHeight(10);
	
	artillerieCase.setFill(Color.RED);
	
	posMouse.setFill(Color.RED);
	posMouse.setStroke(Color.BLACK);
	
	artillerieCase.setX(0);
	artillerieCase.setY(0);
	
	
	primaryStage.setScene(scene);
	primaryStage.show();
	}
	
	static public Rectangle getCliqueIci() {
		return cliqueIci;
	}
	
	
	static public Rectangle createCase(int platID, int numX, int numY, Color d){
		Rectangle r = new Rectangle();
		
		
		r.setX((numX * (spaceBetweenCase + tailleCase)) + (((JeuPlat.getPlatTaille()*(spaceBetweenCase + tailleCase)) + platSpace)*(platID-1)));
		r.setY(numY * (spaceBetweenCase + tailleCase));
		
		r.setWidth(tailleCase);
		r.setHeight(tailleCase);
		r.setArcWidth(1);
		r.setArcHeight(1);
		
		r.setFill(d);
		r.setStroke(Color.BLUE);
		
		
		plat.getChildren().add(r);
		
		return r;
	}
	
	static public void victoryBox(JeuPlat jPlat) {
		Stage secondaryStage = new Stage();
		secondaryStage.setTitle("VOUS AVEZ GAGNE");
		
		Image image = new Image("file:src/image/victoire.jpg");
		ImageView mv = new ImageView(image);
		
		
		StackPane img = new StackPane();
		img.getChildren().add(mv);
		Scene scene = new Scene(img,800,75);
		
		JeuPlat.setActivate(false);
		primaryStage.close();
		
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	static public void defeatBox(JeuPlat jPlat) {
		Stage secondaryStage = new Stage();
		secondaryStage.setTitle("VOUS AVEZ PERDU");
		
		Image image = new Image("file:src/image/defaite.jpg");
		ImageView mv = new ImageView(image);
		
		
		StackPane img = new StackPane();
		img.getChildren().add(mv);
		Scene scene = new Scene(img,800,75);
		
		JeuPlat.setActivate(false);
		primaryStage.close();
		
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	static public void sinkBox() {
		Stage secondaryStage = new Stage();
		secondaryStage.setTitle("VOUS AVEZ COULE UN BATEAU YOUHOUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU");
		
		Image image = new Image("file:src/image/naufrage.jpg");
		ImageView mv = new ImageView(image);
		
		
		StackPane img = new StackPane();
		img.getChildren().add(mv);
		Scene scene = new Scene(img,400,225);
		
		secondaryStage.setScene(scene);
		secondaryStage.show();
	}
	
	static public void removeBoat(Bateau b) {
		for(Circle c : b.getListPointBoat()) {
			plat.getChildren().remove(c);
		}
	}
	
	public static void mouseCase(double posX, double posY, JeuPlat Jplat) {
		// combien de fois on peut mettre l'espace qu'occupe une case (+ espace) dans l'endroit o� est la souris
		// c'est comme �a que je d�termine �a.
		//Math�matique la multiplication n'annule pas la division, car la division est euclidienne. Le r�sultat devient diff�rent
		
		if(ModeJeu.getModeTitre() == "OperationArtillerie") {
			if(JeuPlat.getJeuPlatActif()) {
				if(!animateCurrently) {
					lineCase(((int) posY) / (spaceBetweenCase + tailleCase), Jplat);
				}else {
					if(!listeZoneRad.isEmpty()) {
						for(Rectangle b : listeZoneRad) {
							plat.getChildren().remove(b);
						}
					}
				}
				
			}
			
			
			
		}else {
			posMouse.setX((((int) posX) / (spaceBetweenCase + tailleCase)) * (spaceBetweenCase + tailleCase));
			posMouse.setY((((int) posY) / (spaceBetweenCase + tailleCase)) * (spaceBetweenCase + tailleCase));
			plat.getChildren().remove(posMouse);
			plat.getChildren().add(posMouse);
		}
		
		
		
		
		
	}
	
	public static int lineCase(int y, JeuPlat jplat) {
		if(!listeZoneRad.isEmpty()) {
			for(Rectangle b : listeZoneRad) {
				plat.getChildren().remove(b);
			}
		}
		
		
		for(int i = 0; i < JeuPlat.getPlatTaille(); i++) {
			listeZoneRad.add(createCase(jplat.getPlatID(),i, y, Color.RED));
		}
		
		return y;
	}
	
	public static Circle putBoat(int platID, int posX, int posY) {
		Circle circle = new Circle();
		circle.setCenterX(((posX + 1) * (spaceBetweenCase + tailleCase))-tailleCase/2 + (((JeuPlat.getPlatTaille()*(spaceBetweenCase + tailleCase)) + platSpace)*(platID-1)));
		circle.setCenterY(((posY + 1) * (spaceBetweenCase + tailleCase))-tailleCase/2);
		
		circle.setRadius(10.0f);
		circle.setFill(Color.RED);
		
		plat.getChildren().add(circle);
		return circle;
	}
	
	static public void drawPlat(int platID, boolean platTab[][]){
		Group root;
		if(platID == 1) {
			root = rootPlat1;
		}
		else {
			root = rootPlat2;
		}
		
		
		
		for(int i = 0; i < JeuPlat.getPlatTaille(); i++) {
			for(int j = 0; j < JeuPlat.getPlatTaille(); j++) {
				createCase(platID,j, i, Color.GREY);
				if(platTab[j][i]) {
					if(j < 9 && i < 9) {
						Fenetre.putBoat(platID, j+1, i+1);
					}
					
				}
				
			}
		}
		
	}
	
	static public void artillerieAnimation(JeuPlat Jplat, int y, boolean horizontal) {
		if(Jplat.getPlatID() == 2) {
			artillerieCase.setX((convertTabNToN(JeuPlat.getPlatTaille() + Fenetre.getSpaceBetweenPlat())) * (Jplat.getPlatID()-1));
		}else {
			artillerieCase.setX(0);
		}
		
		animateCurrently = true;
		
		animation = new Timeline(new KeyFrame(
				Duration.millis(75),
				(evt) -> {
					double tailleXMax = convertTabNToN(JeuPlat.getPlatTaille()) + (convertTabNToN(JeuPlat.getPlatTaille() + getSpaceBetweenPlat())) * (Jplat.getPlatID()-1);
					double tailleXMin =0 + (convertTabNToN(JeuPlat.getPlatTaille() + getSpaceBetweenPlat())) * (Jplat.getPlatID()-1);
					
					double tailleY = convertTabNToN(JeuPlat.getPlatTaille());
					
					if(artillerieCase.getX() >= tailleXMax - convertTabNToN(1) || artillerieCase.getY() > tailleY ) {
						artillerieDir = -1;
					} 
					if(artillerieCase.getX() <= tailleXMin || artillerieCase.getY() < 0){
						artillerieDir = 1;
					}
			
					if(horizontal) {
						artillerieCase.setX(artillerieCase.getX() + convertTabNToN(artillerieDir));
						artillerieCase.setY(convertTabNToN(y));
					}else {
						artillerieCase.setY(artillerieCase.getY() + convertTabNToN(artillerieDir));
						artillerieCase.setX(convertTabNToN(y));
					}
						
				
					plat.getChildren().remove(artillerieCase);
					plat.getChildren().add(artillerieCase);
					
					if(Jplat.getCommandor() == "IA") {
						if(ModeJeu.getModeTitre() == "OperationArtillerie") {
							if(horizontal) {
								IA.feuArtillerie(Jplat,convertNToTabN(artillerieCase.getX()) - JeuPlat.getPlatTaille() - spaceBetweenPlat, horizontal);
							}else {
								IA.feuArtillerie(Jplat,convertNToTabN(artillerieCase.getY()), horizontal);
							}
						}else {
							IA.feuArtillerieAR(Jplat,convertNToTabN(artillerieCase.getX()) - JeuPlat.getPlatTaille() - spaceBetweenPlat, horizontal);

						}
							
							
					}
		}));
		animation.setCycleCount(Timeline.INDEFINITE);
		animation.play();
	}
	
	static public void radarAnimation(int platID, int centreX, int centreY, int pX, int pY, JeuPlat jp) {
		
		if(animation != null) {
			animation.stop();
			for(Rectangle r : listeZoneRad) {
				plat.getChildren().remove(r);
				}
		}
		//------------------
		animateCurrently = true;
		int lgC = Math.max(Math.abs(centreX - pX), Math.abs(centreY - pY));
		int pointDepX = centreX - lgC;
		int pointDepY = centreY - lgC;
		
		radarClignote = true;
		//------------------
		animation = new Timeline(new KeyFrame(
				Duration.millis(500),
				(evt) -> {
		for(int i = 0; i <=  2* lgC; i++) {
			for (int j = 0; j <=  2* lgC; j++) {
				if ((pointDepX + j < JeuPlat.getPlatTaille()) && (pointDepY + i < JeuPlat.getPlatTaille()) && (pointDepX + j >= 0) && (pointDepY + i >= 0)) {
						if(i == 0 || i == 2*lgC) {
							if(radarClignote) listeZoneRad.add(createCase(platID, pointDepX + j, pointDepY + i, Color.RED));
						}
						
					if((j == 0 || j == 2 * lgC ) &&(i <= 2*lgC ) ) {
						if(radarClignote) listeZoneRad.add(createCase(platID, pointDepX + j, pointDepY + i, Color.RED));
					}
					if(!radarClignote) {
						
						for(Rectangle r : listeZoneRad) {
						plat.getChildren().remove(r);
						}
					}
				}	
				
			}
		}
		
		
		radarClignote = !radarClignote;
		
				}));
		animation.setCycleCount(4);
		animation.play();
		
			animation.setOnFinished(event -> 
				envoieIA(jp));
	}
	
	static public void envoieIA(JeuPlat jp) {
		if(jp2.getCommandor() == "IA" && jp2 != jp) {
			IA.doAction(jp2);
		}
		animateCurrently =false;
	}
	
	static public void animationAlerteRouge(JeuPlat Jplat) {
		alerteRougeY = 0;
		animateCurrently = true;
		
		animation = new Timeline(new KeyFrame(
				Duration.millis(75),
				(evt) -> {
					
					if(alerteRougeY >= JeuPlat.getPlatTaille() - 1) {
						artillerieDir = -1;
					} 
					if(alerteRougeY <= 0){
						artillerieDir = 1;
					}
					
					lineCase(alerteRougeY + artillerieDir, Jplat);
					
					
					if(Jplat.getCommandor() == "IA") {
						AlerteRouge.feuArtillerie(alerteRougeY + artillerieDir, Jplat);
					}
					alerteRougeY += artillerieDir;
				}));
		animation.setCycleCount(Timeline.INDEFINITE);
		animation.play();
		
	}
	
	static public int convertNToTabN(double x) {
		return (((int)x / (spaceBetweenCase + tailleCase)));
	}
	
	static public double convertTabNToN(int x) {
		return ((double) (x * (spaceBetweenCase + tailleCase))); 
	}
	
	static public int stopArtillerieAnim(boolean horizontal) {
		if(animation != null) {
			animateCurrently = false;
			animation.stop();
			plat.getChildren().remove(artillerieCase);
			if (horizontal) return convertNToTabN(artillerieCase.getX());
			else return convertNToTabN(artillerieCase.getY());
		}
		return 0;
	}
	
	static public void stopMissionRadarZone() {
		if(animation != null) animation.stop();
		if(jp2.getCommandor() == "IA")IA.doAction(jp2);
		
	}
	
	static public int stopAnimationAlerteRouge() {
		animation.stop();
		animateCurrently = false;
		if(!listeZoneRad.isEmpty()) {
			for(Rectangle b : listeZoneRad) {
				plat.getChildren().remove(b);
			}
		}
		return alerteRougeY;
	}
	
	static public void clearLineMouseCase(){
		if(!listeZoneRad.isEmpty()) {
			for(Rectangle r: listeZoneRad) {
				plat.getChildren().remove(r);
			}
			listeZoneRad.clear();
		}
	}
	
	
}


