package fr.controller.warshipcils;

import fr.view.warshipcils.Fenetre;
import fr.model.warshipcils.JeuPlat;
import fr.model.warshipcils.IA;
import fr.model.warshipcils.BatailleClassique;
import fr.model.warshipcils.MissionRadar;
import fr.model.warshipcils.ModeJeu;
import fr.model.warshipcils.Bateau;

// IL FAUDRA ENLEVER L'IMPORT DU MAIN
import fr.model.warshipcils.Main;

import java.util.ArrayList;


import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.Group;



public class Souris{
	
	
	static public JeuPlat jp1 = Main.getPlat(1);
	static public JeuPlat jp2 = Main.getPlat(2);
	
	static double mouseX;
	static double mouseY;
	
	static int dX = 0;
	static int dY = 0;
	
	static public boolean turn1 = (jp1.getYourTurn());
	static public boolean turn2 = (jp2.getYourTurn());
	
	static public boolean modePoseBoat = true;
	
	static public int mouseOnPlat = 1;
	
	static public boolean mouseClick = true;
	
	static public JeuPlat plateau = jp2;
	
	static public JeuPlat mousePlateau = jp1;
	
	static public ArrayList<String> listeBoatPut = plateau.getListBoatToPut();
	
	static public boolean modePoseBateau = true;
	
	
	static public void mouseAction(Group root) {
		
		
		root.setOnMouseReleased(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent arg0) {
				mouseClick = false;
			}
			
		});
		
		root.setOnMouseMoved(new EventHandler<MouseEvent>() {
		      @Override 
		      public void handle(MouseEvent event) {
		    	  
		    	  if ((dX > JeuPlat.getPlatTaille()) ) {
		    		  mouseOnPlat = 2;
		    		  mousePlateau = jp2;
		    	  }
			    	else if ((dX < JeuPlat.getPlatTaille() + 1)) {
			    		mouseOnPlat = 1;
			    		mousePlateau = jp1;
			    	}
		    	  
		    dX = ((((int) mouseX) /(Fenetre.getSpace() + Fenetre.getTailleCase())));
		  	dY = ((((int) mouseY) /(Fenetre.getSpace() + Fenetre.getTailleCase())));
		  		 
		    mouseX = event.getX();
		    mouseY = event.getY();
		    moveMouseAction(root);
		        }
		    });
		
		
		
		root.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override 
		      public void handle(MouseEvent event) {
			
				
			if(JeuPlat.getJeuPlatActif()) {
				clickMouseGameAction(root);
				turn1 = (jp1.getYourTurn());
				turn2 = (jp2.getYourTurn());
			}
			else {
				//je dis qu'il pose les bateaux dans le plateau d�sign�.
				if(mouseOnPlat == 2 && plateau == jp2) {
					clickMousePutBoat(plateau, event);
				}else if(mouseOnPlat ==1 && jp1 == plateau){
					clickMousePutBoat(plateau, event);
				}
				
			}
			mouseClick = true;
			if(!modePoseBoat) {
				if(turn1) {
					Fenetre.getCliqueIci().setX(85);
				}else {
					Fenetre.getCliqueIci().setX(Fenetre.convertTabNToN(JeuPlat.getPlatTaille() + Fenetre.getSpaceBetweenPlat()) + 85 );
				}
				}else {
					if(turn1) {
						Fenetre.getCliqueIci().setX(Fenetre.convertTabNToN(JeuPlat.getPlatTaille() + Fenetre.getSpaceBetweenPlat()) + 85);
					}else {
						Fenetre.getCliqueIci().setX(85);
					}
			}
			}
		});
	}
	
	static public void moveMouseAction(Group root) {
		if(!modePoseBoat) {
			if (turn1) {
				if ((mouseOnPlat == 1)) {
					Fenetre.mouseCase(mouseX, mouseY,mousePlateau);
				}		
			}else {
				if ((mouseOnPlat == 2)) {
					Fenetre.mouseCase(mouseX, mouseY,mousePlateau);
				}
			}
		}
		
	}
	
	// DEGAGER CETTE FONCTION DE LA CLASSE SOURIS ET LA FOUTRE DANS LE MODELE
	static public void setTurn(JeuPlat plat, boolean b){
		if (plat.getPlatID() == 1) {
			turn1 = b; 
			turn2 = !b;
		}
		else{
			turn2 = b;
			turn1 = !b;
		}
	}
	// A MODIFIER ICI ON VA CHERCHER LES OBJETS JEUPLAT DANS LE MAIN DU MODEL CAR IL FAUT
	// UNE CLASSE QUI INSTANCE CES DEUX OBJETS !!!
	
	
	static public void clickMouseGameAction(Group root) {
		if(ModeJeu.getModeTitre() == "OperationArtillerie") {
			Fenetre.clearLineMouseCase();
		}
		
		if (mouseOnPlat == 1 && turn1) {
		ModeJeu.getMode().doAction(dX, dY, jp1);
		}
		else if ((mouseOnPlat == 2) && turn2 && jp2.getCommandor() == "joueur"){
		ModeJeu.getMode().doAction(dX - JeuPlat.getPlatTaille() - Fenetre.getSpaceBetweenPlat(), dY, jp2);
		}
		
		
	}
	
	static public void clickMousePutBoat(JeuPlat jp,MouseEvent e) {
		
		boolean d = true;
		
		if (e.getButton() == MouseButton.SECONDARY) d = false;	
		else d = true;
		
		if(!jp.getCase(dX - ((Fenetre.getSpaceBetweenPlat() + JeuPlat.getPlatTaille())*(jp.getPlatID()-1)), dY)) {
			// DEPLACER CETTE FONCTION DANS LE MODEL
			if (!listeBoatPut.isEmpty()) {
				// ICI ERREUR SI TU POSES UN BATEAU SUR UN PLATEAU ET QUE C'EST PAS TON TOUR
				Bateau.createBoat(listeBoatPut.get(0), dX - ((Fenetre.getSpaceBetweenPlat() + JeuPlat.getPlatTaille())*(jp.getPlatID()-1)), dY, d,jp);
				listeBoatPut = jp.getListBoatToPut();
			}
			
			if (listeBoatPut.isEmpty()){
				
			if(jp2.getCommandor() == "IA") {
				
				while(!jp1.getListBoatToPut().isEmpty()) {
					listeBoatPut = jp1.getListBoatToPut();
					int x1 =(int) (Math.random() * 10);
					int y1 =(int) (Math.random() * 10);
					boolean dir = (int) (Math.random() * 10) > 5 ? true : false;
					Bateau.createBoat(listeBoatPut.get(0), x1 , y1, dir,jp1);
				}
				setTurn(jp2, false);
				setTurn(jp1, true);
				JeuPlat.setActivate(true);
				modePoseBoat = false;
				if(!Main.getDemo()) jp1.dessinerPlateau();
			}else {
				if (plateau.getPlatID() == 1){
					JeuPlat.setActivate(true);
					modePoseBoat = false;
					jp1.dessinerPlateau();
				}
						
						
				setTurn(JeuPlat.getAutrePlateau(jp), false);
				setTurn(jp, true);
				plateau = jp1;
				listeBoatPut = plateau.getListBoatToPut();
				
			}
			if(!Main.getDemo()) jp2.dessinerPlateau();
			
		}
		}else {
			jp.touchBoat(dX - ((Fenetre.getSpaceBetweenPlat() + JeuPlat.getPlatTaille())*(jp.getPlatID()-1)), dY);
		}
	}
	
	static public int getDX() {
		return dX;
	}
	
	static public int getDY() {
		return dY;
	}
	
	static public double getMouseX() {
		
		return mouseX;	
	}
	
	static public double getMouseY() {
		
		return mouseY;	
	}
	
	static public boolean getMouseClick() {
		return mouseClick;
	}
	
	static public JeuPlat getMouseOnPlat() {
		return mousePlateau;
	}
	
	static public boolean getModePoseBateau() {
		return modePoseBateau;
	}
}
