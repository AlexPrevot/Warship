package fr.model.warshipcils;

import fr.view.warshipcils.Fenetre;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import fr.view.warshipcils.Menu;;
// CE MAIN SERA SUPPRIME, je l'utilise pour simuler les conditions du jeux
// comme la cr�ation d'un bateau, d'un plateau, et d'un tire � des coordonn�es, une fois que
// on aura cod� le reste, il ne servira plus � rien

public class Main{
	
	static JeuPlat plateau1;
	static JeuPlat plateau2;
	
	static String modeJeu;
	static String player;
	static int nbrBoat = 0;
	static Fenetre gamePlay;
	static boolean modeDemo = false;
	
	public static void main(String[] args) {	
		Menu truc1 = new Menu();
		
		truc1.main(args);
		
		}
	
	public static JeuPlat getPlat(int i) {
		if (i == 1) return plateau1;
		else return plateau2;
	}
	
	static public void setMode(String s1, String s2, int x) {
		modeJeu = s1;
		player = s2;
		nbrBoat = x;
		
		setGame();
		
		gamePlay = new Fenetre();
		gamePlay.start();
	}
	
	static public void setDemot() {
		modeDemo = true;
	}
	
	static public boolean getDemo() {
		return modeDemo;
	}
	
	static public void setGame() {
		// je cr�er un plateau, qui est le plateau d'un joueur, l� o� il pourra tirer
				plateau1 = new JeuPlat(10, "joueur");
				
				plateau2 = new JeuPlat(10, player);
				
				JeuPlat[] l = {plateau1, plateau2};
				
				//Je met le mode de jeu, � mettre avant l'initialisation des plateau
				ModeJeu.setMode(modeJeu, l);
				
				//j'initialise les bateaux � poser dans les plateaux
				String [] nomB = new String[nbrBoat];
				
				for (int i = 0; i < nomB.length; i++) {
					if(i == 0)  nomB[0] = "porte-avions";
					if(i == 1) nomB[1] = "cuirasse furtif";
					if(i == 2) nomB[2] = "cuirasse furtif";
					if(i == 3) nomB[3] = "zodiac";
					if(i == 4) nomB[4] = "sous-marin nucleaire";
					
					plateau1.newBoatToPut(nomB[i]);
					plateau2.newBoatToPut(nomB[i]);
				}
				

				// je dessine le plateau
				plateau1.dessinerPlateau();
				
				plateau2.dessinerPlateau();
				
				// je dis que le plateau 1 se fait tier dessus en premier
				plateau1.changeTurn();
				
		
	}
}
