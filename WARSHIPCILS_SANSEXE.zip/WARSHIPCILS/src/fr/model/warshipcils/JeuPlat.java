package fr.model.warshipcils;

import java.util.ArrayList;
import java.util.Iterator;

import fr.controller.warshipcils.Souris;
import fr.view.warshipcils.Fenetre;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.io.*;

public class JeuPlat {
	static int platTaille;
	boolean platTab[][];
	String commandor;// joueur ou IA
	static int nbPlat = 0;
	int platID;
	static boolean activate = false; // on le bloque � true pour l'instant, plus tard, il faudra enlever true pour que le jeu ne fonctionne pas dans menu etc...
	boolean yourTurn = false;
	public boolean artillerieDejaTire = false;
	public ArrayList<Bateau> listBoatPuted = new ArrayList<Bateau>(); //liste des bateaux sur le plateau
	public ArrayList<Bateau> listBoatReplace = new ArrayList<Bateau>();
	public ArrayList<String> listBoatToPut = new ArrayList<String>(); //liste des bateaux qu'on veut poser sur le plateau
	
	
	public JeuPlat(int taille, String joueur) {
		platTaille = taille;
		nbPlat++;
		platID = nbPlat;
		this.commandor = joueur;
		platTab = new boolean[platTaille][platTaille];
		prepPlat();
	}
	
	public String getCommandor() {
		return commandor;
	}
	
	public boolean[][] getPlatTab(){
		return this.platTab;
	}
	
	public int getPlatID() {
		return this.platID;
	}
	
	static public int getPlatTaille() {
		return platTaille;
	}
	
	public boolean getDejaTire() {
		return this.artillerieDejaTire;
	}
	
	public void changeDejaTir() {
		this.artillerieDejaTire = !this.artillerieDejaTire;
	}
	
	public void setDejaTir(boolean t) {
		this.artillerieDejaTire = t;
	}
	
	public void unSetCase(Bateau b) {
		int x = b.getX();
		int y = b.getY();
		boolean verticale = b.getDir();
		int tailleB = b.getLengthBateau();
		
		if(verticale) {
			for(int i = y; i < y + tailleB; i++) {
				platTab[x][i] = false;
			}
		}else {
			for(int i = x; i < x + tailleB; i++) {
				platTab[i][y] = false;
			}
		}
	}
	
	public void touchBoat(int coordX, int coordY){
		if(!this.listBoatPuted.isEmpty()) {
			Iterator<Bateau> itr = listBoatPuted.iterator();
			
			while(itr.hasNext()) {
				Bateau e = itr.next();
				if(e.getDir()) {
					if(e.getX() == coordX) {
						for(int i = e.getY(); i < e.getY() + e.getLengthBateau(); i++) {
							if(i == coordY) {
								unSetCase(e);
								Fenetre.removeBoat(e);
								listBoatToPut.add(0,e.getName());
								itr.remove();
							}
						}
					}
				}else {
					if(e.getY() == coordY) {
						for(int i = e.getX(); i < e.getX() + e.getLengthBateau(); i++) {
							if(i == coordX) {
								unSetCase(e);
								Fenetre.removeBoat(e);
								listBoatToPut.add(0,e.getName());
								itr.remove();
							}
						}
					}
				}
				
			}
		}
	}
	
	//La case en param�tre sera dite "occup�" si cette fonction est appel�
	public Circle setCase(int coordX, int coordY) {
		Circle c;
		this.platTab[coordX][coordY] = true;
		c =Fenetre.putBoat(this.platID,coordX,coordY);
		
		return c;
	}
	//la case en param�tre sera dite "vide" si cette fonction est appel�
	public void destroyCase(int coordX, int coordY) {
		Color d;
		
		if (platTab[coordX][coordY]) {
			hitBoat(coordX,coordY);
			d = Color.DARKRED;
		}
		else d = Color.DARKBLUE;
		
		this.platTab[coordX][coordY] = false;
		
		int rdX;
		
		if (Souris.getDX() > platTaille - 1 )  rdX = Souris.getDX() - platTaille - Fenetre.getSpaceBetweenPlat();
		else rdX = Souris.getDX();
		
		Fenetre.createCase(platID, coordX, coordY, d);
	}
	
	public void hitBoat(int coordX, int coordY) {
		if(!this.listBoatPuted.isEmpty()) {
			Iterator<Bateau> itr = listBoatPuted.iterator();
			
			while(itr.hasNext()) {
				Bateau e = itr.next();
				if(e.getDir()) {
					if(e.getX() == coordX) {
						for(int i = e.getY(); i < e.getY() + e.getLengthBateau(); i++) {
							if(i == coordY) {
								e.getHit(this);
							}
						}
					}
				}else {
					if(e.getY() == coordY) {
						for(int i = e.getX(); i < e.getX() + e.getLengthBateau(); i++) {
							if(i == coordX) {
								e.getHit(this);
							}
						}
					}
				}
				if(e.getVie() == 0) itr.remove();
			}
		}
		if(this.listBoatPuted.isEmpty()) {
				
			if(JeuPlat.getAutrePlateau(this).getCommandor() == "IA" && this.commandor == "joueur") {
				activate = false;
				Fenetre.victoryBox(this);
			}else if(JeuPlat.getAutrePlateau(this).getCommandor() == "joueur" && this.commandor == "joueur"){
				activate = false;
				Fenetre.victoryBox(this);
			}else if(JeuPlat.getAutrePlateau(this).getCommandor() == "joueur" && this.commandor == "IA"){
				activate = false;
				Fenetre.defeatBox(this);
			}
			
		}
		
	}
	
	static public JeuPlat getAutrePlateau(JeuPlat jp) {
		if(jp.getPlatID() == 1) return Main.getPlat(2);
		else return Main.getPlat(1);
	}
	
	//v�rifie si la case en param�tre est occup� ou non 
	public boolean getCase(int coordX, int coordY) {
		if (this.platTab[coordX][coordY]) {
			return true;
		}
		return false;
	}
	
	public void prepPlat() {
		for(int i = 0; i < this.platTab.length; i++) {
			for(int j = 0; j < this.platTab[i].length; j++) {
				this.platTab[j][i] = false;
			}
		}
	}
	
	// l� c'est uniquement pour faire des tests, on devra supprimer/modifier apr�s
	
	public void dessinerPlateau() {
		Fenetre.drawPlat(this.platID, this.platTab);
	}
	
	//////////////////////////////////////////////////////////////// Tout ce qu'il y a au dessus ne d�marrera que si JeuPlat est actif, et si c'est au tour
	// du plateau de jouer.
	
	static public boolean getJeuPlatActif() {
		return activate;
	}
	
	static public void setActivate(boolean b) {
		if (b) activate = true;
		else activate = false;
	}
	
	public boolean getYourTurn() {
		return this.yourTurn;
	}
	
	public void setTurn(boolean b) {
		yourTurn = b;
	}
	
	public void changeTurn() {
		this.yourTurn = !(this.yourTurn);
	}
	
	///////////////////////////////////////////////////////////////////////////////////////:
	
	public void newBoatOnPlat(Bateau b) {
		this.listBoatPuted.add(b);
	}
	
	public ArrayList getListBoatPuted() {
		return listBoatPuted;
	}
	
	public void newBoatToPut(String b) {
		this.listBoatToPut.add(b);
	}
	
	public ArrayList<String> getListBoatToPut() {
		return listBoatToPut;
		
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////
	
	public int[] closestPointFrom(int x, int y) {
		
		int[] closestPoint = new int[2];
		
		double dist = 0.0;
		double distCourt = JeuPlat.getPlatTaille();
		
		for(Bateau b: listBoatPuted) {
			
			dist = (x - b.closestBoatPointFrom(x, y)[0]) * (x - b.closestBoatPointFrom(x, y)[0]) + (y - b.closestBoatPointFrom(x, y)[1]) * (y - b.closestBoatPointFrom(x, y)[1]) ;
			dist = Math.sqrt(dist);

			if(dist < distCourt) {
				distCourt = dist;
				
				closestPoint[0] = b.closestBoatPointFrom(x, y)[0];
				closestPoint[1] = b.closestBoatPointFrom(x, y)[1];
			}
		}
		return closestPoint;
	}
	//-----------------------------------------------------------------------------------------------------------
	
	public void radarZone(int centreX, int centreY, int pX, int pY) {
		Fenetre.radarAnimation(this.platID, centreX, centreY, pX, pY,this);
		
	}
	
	//-----------------------------------------------------------------------------------------------------------------
	
	public void executeMissionRad(int shotX, int shotY) {
		int[] boatPoint = closestPointFrom(shotX, shotY);
		radarZone(shotX, shotY, boatPoint[0], boatPoint[1]);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public void executeOperationArtillerie(int shotY,boolean horizontal) {
				Fenetre.artillerieAnimation(this,shotY, horizontal);
		   }
		

}