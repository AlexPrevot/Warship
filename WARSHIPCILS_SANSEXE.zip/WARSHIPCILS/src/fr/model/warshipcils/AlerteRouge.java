package fr.model.warshipcils;

import fr.view.warshipcils.Fenetre;

public class AlerteRouge extends ModeJeu{
	static boolean hasShot = false;
	static int shotY;
	static OperationArtillerie oa = new OperationArtillerie();
	static MissionRadar mr = new MissionRadar();
	
	public AlerteRouge() {
		
	}
	
	@Override
	public void doAction(int coordX,int coordY, JeuPlat jp) {
		
		if(!hasShot) {
			shotY = coordY;
			Fenetre.animationAlerteRouge(jp);
			hasShot = !hasShot;
		}
		else{
			if (jp.getCommandor() == "joueur") {
				shotY = Fenetre.stopAnimationAlerteRouge();
				oa.doActionAR(0, shotY, jp,mr);
			}
			
		}
		
	}
	
	static public void setHaShot() {
		hasShot = false;
	}
	
	static public void feuArtillerie(int y, JeuPlat jp) {
		if(y == IA.getRY()+1) {
			shotY = Fenetre.stopAnimationAlerteRouge();
			oa.doActionAR(0, shotY, jp,mr);
		}
	}
	
	static public MissionRadar getMR() {
		return mr;
	}

}
