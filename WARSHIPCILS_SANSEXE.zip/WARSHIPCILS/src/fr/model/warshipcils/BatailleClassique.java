package fr.model.warshipcils;

public class BatailleClassique extends ModeJeu{
	
	public BatailleClassique() {
		
	}
	
	@Override
	public void doAction(int coordX, int coordY, JeuPlat jp) {
		tirer(coordX,coordY, jp);
		
	}

}
