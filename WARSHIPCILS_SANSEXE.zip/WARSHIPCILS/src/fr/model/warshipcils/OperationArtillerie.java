package fr.model.warshipcils;

import fr.view.warshipcils.Fenetre;

public class OperationArtillerie extends ModeJeu {
	
	static public boolean dejaTire = false;
	int shotY = 0;
	boolean horizontal;
	
	public OperationArtillerie() {
		
	}
	
	@Override
	public void doAction(int coordX,int coordY, JeuPlat jp) {
		coordX=0;
		
		if(!jp.getDejaTire()) {
			if(coordX==0) horizontal = true;
			else{
				coordY =0;
				horizontal = false;
			}
			if (!Fenetre.getIsAnimating()) {
				if (horizontal) balayage(coordY, jp,horizontal);
				else balayage(coordX + ((Fenetre.getSpaceBetweenPlat() + JeuPlat.getPlatTaille()) * (jp.getPlatID() -1)), jp,horizontal);
			}
		}
		else {
			feu(jp);
		}
	}
	
	public void balayage(int coordY, JeuPlat jp, boolean horizontal) {
		jp.changeDejaTir();
		jp.executeOperationArtillerie(coordY, horizontal);
		shotY = coordY;
	}
	
	public void feu(JeuPlat jp) {
		int shotX = Fenetre.stopArtillerieAnim(horizontal);
		jp.changeDejaTir();
		if(horizontal) tirer(shotX - ((Fenetre.getSpaceBetweenPlat() + JeuPlat.getPlatTaille()) * (jp.getPlatID() -1)),shotY, jp);
		else tirer(shotY - ((Fenetre.getSpaceBetweenPlat() + JeuPlat.getPlatTaille()) * (jp.getPlatID() -1)), shotX, jp);
	}
	
	public void doActionAR(int coordX,int coordY, JeuPlat jp, MissionRadar mr) {
		coordX=0;
		
		if(!jp.getDejaTire()) {
			if(coordX==0) horizontal = true;
			else{
				coordY =0;
				horizontal = false;
			}
			if (!Fenetre.getIsAnimating()) {
				if (horizontal) balayage(coordY, jp,horizontal);
				else balayage(coordX + ((Fenetre.getSpaceBetweenPlat() + JeuPlat.getPlatTaille()) * (jp.getPlatID() -1)), jp,horizontal);
			}
		}
		else {
			if(jp.getCommandor() == "joueur") {
				int shotX = Fenetre.stopArtillerieAnim(horizontal);
				jp.changeDejaTir();
				
					mr.doAction(shotX - ((Fenetre.getSpaceBetweenPlat() + JeuPlat.getPlatTaille()) * (jp.getPlatID() -1)),shotY, jp);
				
			}
		}
	}
	
	static public void setHasShot(){
		dejaTire = false;
	}
	
}