package fr.model.warshipcils;

import fr.view.warshipcils.Fenetre;

public class MissionRadar extends ModeJeu {
	int caseX = 0;
	public MissionRadar() {
		
	}
	
	@Override
	public void doAction(int coordX,int coordY, JeuPlat jp) {
			

		if(ModeJeu.getModeTitre() == "AlerteRouge") {
			AlerteRouge.setHaShot();
			OperationArtillerie.setHasShot();
			jp.setDejaTir(false);
		}
		
			if(!jp.getCase(coordX, coordY)) {
				jp.executeMissionRad(coordX, coordY);
				tirer(coordX,coordY, jp);
			}else {
				if(jp.getCommandor() == "joueur") Fenetre.stopMissionRadarZone();
				tirer(coordX,coordY, jp);
			}
			
	}
	
	

}
