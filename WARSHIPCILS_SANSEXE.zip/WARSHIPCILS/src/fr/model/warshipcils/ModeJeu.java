package fr.model.warshipcils;

import fr.view.warshipcils.Fenetre;

public abstract class ModeJeu {
	
	static ModeJeu modeEnCours;
	static JeuPlat[] l;
	static String mode;
	static int IAShotX;
	static int IAShotY;
	
	static public void setMode(String s, JeuPlat listPlat[]) {
		mode = s;
		l = listPlat;
		if(s == "BatailleClassique") modeEnCours = new BatailleClassique();
		else if (s == "MissionRadar") modeEnCours = new MissionRadar();
		else if (s == "OperationArtillerie") modeEnCours = new OperationArtillerie();
		else if (s == "AlerteRouge") modeEnCours = new AlerteRouge();
	}
	
	static public ModeJeu getMode() {
		return modeEnCours;
	}
	
	static public String getModeTitre() {
		return mode;
	}
	
	static public void tirer(int coordX, int coordY, JeuPlat jp) {
		jp.destroyCase(coordX, coordY);
		
		changeTurn();
	}
	
	public void doAction(int coordX, int coordY, JeuPlat jp) {
		System.out.println("JE SUIS BLOQUE MODEJEU");
	}
	static public void changeTurn() {
		l[1].setTurn(l[0].getYourTurn());
		l[0].setTurn(!l[1].getYourTurn());

		if(l[1].getCommandor() == "IA"  && !Fenetre.getIsAnimating() && l[1].getYourTurn() && JeuPlat.getJeuPlatActif()) {
			IA.doAction(l[1]);
		}
	}

}
