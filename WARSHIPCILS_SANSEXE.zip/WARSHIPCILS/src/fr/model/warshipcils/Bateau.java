package fr.model.warshipcils;

import fr.view.warshipcils.Fenetre;

import java.util.ArrayList;
import java.util.Iterator;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;


public class Bateau {
	String typeBateau;
	JeuPlat jp;
	int lengthBateau;
	boolean direction;
	public int cX;
	public int cY;
	public int listCo[][];
	int vertical;
	int horizontal;
	int vie;
	ArrayList<Circle> pointBoatOnWindow = new ArrayList<Circle>();
	
	public Bateau(String bat, int coordX, int coordY, boolean dir, JeuPlat j_Pt) {
		
		this.typeBateau = bat;
		this.direction = dir;
		
		if (this.typeBateau == "porte-avions") {
			this.lengthBateau = 5;
			this.vie = 5;
		}
		
		if (this.typeBateau == "cuirasse furtif") {
			this.lengthBateau = 3;
			this.vie = 3;
		}
		
		if (this.typeBateau == "zodiac") {
			this.lengthBateau = 2;
			this.vie = 2;
		}
		
		if (this.typeBateau == "sous-marin nucleaire") {
			this.lengthBateau = 4;
			this.vie = 4;
		}
		
		this.cX = coordX;
		this.cY = coordY;
		this.jp = j_Pt;
		
		vertical = this.direction ? 1 : 0;  //Si vertical verticale = 1, si horizontale vertical = 0
		horizontal = this.direction ? 0 : 1;
		
		listCo = direction ?  (new int[1][lengthBateau]) : ( new int[lengthBateau][1]);
		
		placement(jp);
	}
	
	static public void createBoat(String nom, int coorX, int coorY, boolean dire, JeuPlat Plt) {
		
		int lg = 0;
		
		if (nom == "porte-avions") {
			lg = 5;
		}
		
		if (nom == "cuirasse furtif") {
			lg = 3;
		}
		
		if (nom == "zodiac") {
				lg = 2;
		}
		
		if (nom == "sous-marin nucleaire") {
			lg = 4;
		}
		
		if((lg != 0) && (!mauvaisPlacement(coorX, coorY, lg, dire, Plt))) {
			Bateau b = new Bateau(nom, coorX, coorY, dire, Plt);
		}
		
	}
	
	public int getVie() {
		return this.vie;
	}
	
	public void getHit(JeuPlat jp) {
		this.vie -= 1;
		
		if(this.vie == 0) Fenetre.sinkBox();
	}
	
	public boolean getDir() {
		return this.direction;
	}
	
	public int getX() {
		return this.cX;
	}
	
	public String getName() {
		return this.typeBateau;
	}
	
	public int getY() {
		return this.cY;
	}
	
	public int getLengthBateau() {
		return this.lengthBateau;
	}
	
	public ArrayList<Circle> getListPointBoat() {
		return pointBoatOnWindow;
	}
	
	// Ici je dis que le bateau, sur le plateau du joueur en param�tre
	//va occuper toutes les cases (Bool = true) du tableau qu'il occupe
	//en fonction de sa taille et sa direction
	public void placement(JeuPlat plat) {
			for(int i = 0; i < this.lengthBateau; i++ ) 
			{
			this.listCo[i * horizontal][i * vertical] = (this.cY + i) * vertical + (this.cX + i)* horizontal;
			pointBoatOnWindow.add(plat.setCase(cX + i * this.horizontal,cY + i * vertical));
			}
			plat.listBoatToPut.remove(0);
			plat.newBoatOnPlat(this);
		}
	
	
	
	static public boolean mauvaisPlacement(int x, int y, int lg, boolean dir, JeuPlat jpt) {
		
		if(dir) {
			if((y + lg > JeuPlat.platTaille)) {
				return true;
				
			}else 
			{
				for(int k = 0; k < lg; k++)
				{
					
					if ((jpt.getCase(x, y + k))) 
					{
					return true;
					}
				}
			}
		}
		else {
			if ((x + lg > JeuPlat.platTaille)){
				return true;
			}
			else 
			{
					for(int k = 0; k < lg; k++)
					{
						if ((jpt.getCase(x + k, y))) 
						{
						return true;
						}
					}
			}
		}
		
		return false;
		
	}
	
	public int[] closestBoatPointFrom(int coX, int coY) {
		int[] closestPoint = new int[2];
		double distCourt = JeuPlat.getPlatTaille();
		int dirCoVar = direction ? coY : coX;
		int fixDist = direction ? this.cX - coX : this.cY - coY;
		double dist = 0;

		for(int i = 0; i < this.lengthBateau; i++) {
			dist = (double) (listCo[i * horizontal][i * vertical] - dirCoVar);
			dist = (fixDist * fixDist) + (dist * dist);
			
			dist = Math.sqrt(dist);
			if(direction) {
				if (this.jp.platTab[this.cX][listCo[0][i]]) {
					if(dist <= distCourt) {
						distCourt = dist;
						closestPoint[0] = this.cX;
						closestPoint[1] = listCo[0][i];
					}
				}
			}else {
				if (this.jp.platTab[listCo[i][0]][this.cY]) {
					if(dist <= distCourt) {
						distCourt = dist;
						closestPoint[0] = listCo[i][0];
						closestPoint[1] = this.cY;
						}
					}
				}
			
		}
		return closestPoint;
	}


	
	
}
