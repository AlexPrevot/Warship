package fr.model.warshipcils;

import fr.view.warshipcils.Fenetre;

public class IA {
	static String controleur;
	static int hasHit;
	static int randomX;
	static int randomY;
	
	public IA() {
	
		
	}

	static public void doAction(JeuPlat jp) {
		shotIA(jp);
	}
	
	static public void shotIA(JeuPlat jp) {
		int max = JeuPlat.getPlatTaille();
		int min = 0; // ATTENTION ICI CA PEUT FAIRE DE LA MERDE SI JAMAIS ON DEPLACE LA CARTE/////////////////////////////////////////
		
		boolean[][] tabOfPlat = jp.getPlatTab();
		hasHit = (int) (Math.random() * max);
		randomX = (int) (Math.random() * max);
		randomY = (int) (Math.random() * max);
		
		if(hasHit >= 2) {
			if(ModeJeu.getModeTitre() == "OperationArtillerie") {
				feuArtillerie(jp,0,true);
			}else {
				ModeJeu.getMode().doAction(randomX, randomY, jp);
			}
			
		}else {
			while(!tabOfPlat[randomX][randomY]) {
				randomX = (int) (Math.random() * max);
				randomY = (int) (Math.random() * max);
			}
			
			if(ModeJeu.getModeTitre() == "OperationArtillerie") {
				feuArtillerie(jp,0,true);
			}else {
				ModeJeu.getMode().doAction(randomX, randomY, jp);
			}
		}
	}

	
	static public void feuArtillerie(JeuPlat jp, int shotX, boolean horizontal) {
		
		if(horizontal) {
			if(shotX == randomX || !jp.getDejaTire()) {
				ModeJeu.getMode().doAction(randomX, randomY, jp);
			}
		}else {
			if(shotX == randomY || !jp.getDejaTire()) {
				ModeJeu.getMode().doAction(randomX, randomY, jp);
			}
		}
	}
	
	static public void feuArtillerieAR(JeuPlat jp, int shotX, boolean horizontal) {
		
		if(horizontal) {
			if(shotX == randomX || !jp.getDejaTire()) {
				Fenetre.stopArtillerieAnim(true);
				AlerteRouge.getMR().doAction(randomX, randomY, jp);
			}
		}else {
			if(shotX == randomY || !jp.getDejaTire()) {
				AlerteRouge.getMR().doAction(randomX, randomY, jp);
			}
		}
	}
	
	static public int getRX() {
		return randomX;
	}
	
	static public int getRY() {
		return randomY;
	}
	
	
}
